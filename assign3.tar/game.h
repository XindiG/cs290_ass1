#ifndef INC_11_13_GAME_H
#define INC_11_13_GAME_H

#include "player.h"
/*********************************************************************
** Program Filename:game.h
** Author:Xindi,Guo
** Date:2018/11/13
** Description:game.h
** Input:no
** Output:no
*********************************************************************/

class Game {
public:
    Game();

    // play one turn
    void next_turn();

    // If the game reached the ending. (the bank account is 0 or 1,000,000.)
    bool is_end();

    // after ending, display lose or win
    void display_end();

    // player collect rent, pay mortgage, and pay tax(every 12 turns)
    void update_bank();

    // Each business that pays rent in a complex increases the property value by 1% each turn
    void update_BusinessComplex_value();

    // handle event
    void event_name(int event);
    int random_event();
    void stock_market_crash();
    void gentrification();
    void decrease_value_by_event(int location, double decrease_rate);

    // display menus
    void display_options();

    // If all of those properties have been bought, new ones should be generated
    void generate_properties();
    void show_properties_on_sale();
    void show_choices_to_buy();
    void buy_house();
    void buy_apart();
    void buy_business();

    // handle player's operation
    void handle_buy_property();
    void handle_sell_property();
    void handle_adjust_rents();

private:
    int curr_turn;
    Player* player;
    House* houses[3];
    ApartmentComplex* apartments[3];
    BusinessComplex* businesses[3];
    int num_house_on_sale;
    int num_apart_on_sale;
    int num_business_on_sale;
};

#endif
