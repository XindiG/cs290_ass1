#ifndef INC_11_13_TENANT_H
#define INC_11_13_TENANT_H
/*********************************************************************
** Program Filename:Tenant.h
** Author:Xindi,Guo
** Date:2018/11/13
** Description:tenant's header
** Input:no
** Output:no
*********************************************************************/
class Tenant {
public:
    Tenant();
    int get_agree_score();
    int get_monthly_budget();
    void set_agree_score();
    void set_monthly_budget(int low, int up);

private:
    int monthly_budget;
    int agree_score;
};

class Citizen: public Tenant {
public:
    Citizen();
};

class Business: public Tenant {
public:
    Business();
};

#endif
