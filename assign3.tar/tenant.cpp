#include "tenant.h"
#include<cstdlib>
#include<ctime>
/*********************************************************************
** Program Filename:Tenant.cpp
** Author:Xindi,Guo
** Date:2018/11/13
** Description:tenant's header
** Input:no
** Output:no
*********************************************************************/

/*********************************************************************
** Function:tnenat_tenant
** Description:constructor
*********************************************************************/

Tenant::Tenant() {
    set_agree_score();
}
/*********************************************************************
** Function:get_agree_score
** Description:get the value
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:no
*********************************************************************/

int Tenant::get_agree_score() {
    return agree_score;
}
/*********************************************************************
** Function:get_monthly_budget
** Description:get budget
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:get budget
*********************************************************************/
int Tenant::get_monthly_budget() {
    return monthly_budget;
}
/*********************************************************************
** Function:set_agree_score
** Description:set the value
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:set a proper value
*********************************************************************/
void Tenant::set_agree_score() {
    int score = rand()%5 + 1;
    agree_score = score;
}
/*********************************************************************
** Function:get_agree_score
** Description:set the value
** Parameters:int low int up
** Pre-Conditions:pass in two values
** Post-Conditions:set monthly budget
*********************************************************************/

void Tenant::set_monthly_budget(int low, int up) {
    monthly_budget = (rand()%(up-low+1)) + low;
}
/*********************************************************************
** Function:citizen_citizen
** Description:constructor
*********************************************************************/

Citizen::Citizen() {
    set_agree_score();
    set_monthly_budget(500, 5000);
}

/*********************************************************************
** Function:business_business
** Description:constrcutor
** Parameters:no
*********************************************************************/
Business::Business() {
    set_agree_score();
    set_monthly_budget(2000, 10000);
}
