#include <iostream>
#include "game.h"
/*********************************************************************
** Program Filename:RunGame.cpp
** Author:Xindi,Guo
** Date:2018/11/13
** Description:driver
** Input:no
** Output:no
*********************************************************************/
int main() {
    // set cout format. since almost all data was money, set precision 2
    std::cout.setf(std::ios::fixed,std::ios::floatfield);
    std::cout.precision(2);
    Game* game = new Game();
    while (!game->is_end()) {
        game->next_turn();
    }
    game->display_end();
    return 0;
}