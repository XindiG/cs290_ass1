#include "game.h"
#include <cstdlib>
#include <iostream>
/*********************************************************************
** Program Filename:game.cpp
** Author:Xindi,Guo
** Date:2018/11/13
** Description:game.cpp
** Input:no
** Output:no
*********************************************************************/

/*********************************************************************
** Function:Game
** Description:constructor
*********************************************************************/
Game::Game() {
    player = new Player();
    srand((unsigned)time(0));
    for (int i = 0; i < 3; i++) {
        houses[i] = new House();
        apartments[i] = new ApartmentComplex();
        businesses[i] = new BusinessComplex();
    }
    curr_turn = 0;
    num_house_on_sale = 3;
    num_apart_on_sale = 3;
    num_business_on_sale = 3;
}
/*********************************************************************
** Function:is_end
** Description:win and end the game
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:winner check
*********************************************************************/

bool Game::is_end() {
    if(player->get_bank() <= 0 || player->get_bank() > 1000000) {
        return true;
    }
    return false;
}
/*********************************************************************
** Function:display_end
** Description:lose and end game
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:lose check
*********************************************************************/

void Game::display_end() {
    std::cout << "==========Game end!==========" << std::endl;
    std::cout << "Your finally bank: " << player->get_bank() << std::endl;
    if (player->get_bank() <= 0) {
        std::cout << "You lose this game!" << std::endl;
    } else {
        std::cout << "You win this game!" << std::endl;
    }
}
/*********************************************************************
** Function:update_band
** Description:update band value
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:change band value
*********************************************************************/

void Game::update_bank() {
    player->collect_rent();
    player->pay_mortgage();
    if (curr_turn % 12 == 0) {
        player->pay_tax();
    }
}
/*********************************************************************
** Function:update_businesscomplex_value
** Description:update business complex value
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:change businesscomplex value
*********************************************************************/
void Game::update_BusinessComplex_value() {
    for (int i = 0; i < num_business_on_sale; i++) {
        businesses[i]->update_value();
    }
    player->update_business_value();
}
/*********************************************************************
** Function:event_name
** Description:event surface
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:give event happend information
*********************************************************************/

void Game::event_name(int event) {
    if (event == 0) {
        std::cout << "A hurricane occurs." << std::endl;
    } else if (event == 1) {
        std::cout << "A tornado occurs." << std::endl;
    } else if (event == 2) {
        std::cout << "The earthquake occurs." << std::endl;
    } else if (event == 3) {
        std::cout << "A wildfire occurs." << std::endl;
    } else if (event == 4) {
        std::cout << "Stock market crash." << std::endl;
    } else if (event == 5) {
        std::cout << "Gentrification." << std::endl;
    }
}
//random event: 0=hurricane; 1=tornado; 2=earthquake, 3=wildfire, 4=Stock market crash
                // 5=Gentrification
int Game::random_event() {
    int event = rand()%6;
    event_name(event);
    if (event == 0) {
        decrease_value_by_event(0, 0.5);
    } else if (event == 1) {
        decrease_value_by_event(2, 0.3);
    } else if (event == 2) {
        decrease_value_by_event(4, 1 - 0.1);
    } else if (event == 3) {
        decrease_value_by_event(3, 0.25);
    } else if (event == 4) {
        stock_market_crash();
    } else if (event == 5) {
        gentrification();
    }
}

//0 means SE, 1 means NE, 2 means Midwest, 3 means SW, 4 means NW

void Game::decrease_value_by_event(int location, double decrease_rate) {
    for (int i = 0; i < num_house_on_sale; i ++) {
        if (houses[i] != NULL && houses[i]->get_location() == location) {
            houses[i]->decrease_value(decrease_rate);
        }
    }
    for (int i = 0; i < num_business_on_sale; i ++) {
        if (apartments[i] != NULL && apartments[i]->get_location() == location) {
            apartments[i]->decrease_value(decrease_rate);
        }
    }
    for (int i = 0; i < num_apart_on_sale; i ++) {
        if (businesses[i] != NULL && businesses[i]->get_location() == location) {
            apartments[i]->decrease_value(decrease_rate);
        }
    }
    player->decrease_value_by_event(location, decrease_rate);
}
/*********************************************************************
** Function:stock_market_crash
** Description:event
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:give event result
*********************************************************************/

void Game::stock_market_crash() {
    for (int location = 0; location < 5; location++) {
        decrease_value_by_event(location, 0.3);
    }
}
/*********************************************************************
** Function:gentrification
** Description:event
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:give event result
*********************************************************************/
void Game::gentrification() {
    int location = rand() % 5;
    // Gentrification will !!!increase!!! property value, so decrease a negative rate, means -0.2
    decrease_value_by_event(location, -0.2);
}
/*********************************************************************
** Function:
** Description:
** Parameters:
** Pre-Conditions:
** Post-Conditions:
*********************************************************************/

void Game::display_options() {
    std::cout << "Your option:" << std::endl;
    std::cout << "1. buy a property" << std::endl;
    std::cout << "2. sell a property" << std::endl;
    std::cout << "3. adjust rents on a property" << std::endl;
    std::cout << "4. end this turn(give up this option)" << std::endl;
    std::cout << "Please input a number between 1 to 4:" << std::endl;
}
/*********************************************************************
** Function:
** Description:
** Parameters:
** Pre-Conditions:
** Post-Conditions:
*********************************************************************/

void Game::generate_properties() {
    if (num_apart_on_sale == 0 && num_business_on_sale == 0 && num_house_on_sale == 0) {
        for (int i = 0; i < 3; i++) {
            houses[i] = new House();
            apartments[i] = new ApartmentComplex();
            businesses[i] = new BusinessComplex();
        }
        curr_turn = 0;
        num_house_on_sale = 3;
        num_apart_on_sale = 3;
        num_business_on_sale = 3;
    }
}
/*********************************************************************
** Function:show_property_on_sale
** Description:view the purchase list
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:no
*********************************************************************/

void Game::show_properties_on_sale() {
    generate_properties();
    if (num_house_on_sale > 0) {
        std::cout << "House to purchase:" << std::endl;
        houses[num_house_on_sale - 1]->display();
    } else {
        std::cout << "No House left." << std::endl;
    }
    if (num_apart_on_sale > 0) {
        std::cout << "Apartment Complex to purchase:" << std::endl;
        apartments[num_apart_on_sale - 1]->display();
    } else {
        std::cout << "No Apartment Complex left." << std::endl;
    }
    if (num_business_on_sale > 0) {
        std::cout << "Business Complex to purchase:" << std::endl;
        businesses[num_business_on_sale - 1]->display();
    } else {
        std::cout << "No Business Complex left." << std::endl;
    }
}
/*********************************************************************
** Function:show_choice_to_buy
** Description:show the surface of buying property
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:give a surface
*********************************************************************/

void Game::show_choices_to_buy() {
    std::cout << "Please select a type of property to buy:" << std::endl;
    std::cout << "1. House   2. Apartment Complex  3. Business Complex" << std::endl;
}
/*********************************************************************
** Function:buy_house
** Description:be able to buy property
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:buy property
*********************************************************************/

void Game::buy_house() {
    if (num_house_on_sale == 0) {
        std::cout << "No House left." << std::endl;
    } else {
        num_house_on_sale --;
        player->add_house(houses[num_house_on_sale]);
        houses[num_house_on_sale] = NULL;
    }
}
/*********************************************************************
** Function:buy_apart
** Description:be able to buy property
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:buy property
*********************************************************************/

void Game::buy_apart() {
    if (num_apart_on_sale == 0) {
        std::cout << "No Apartment Complex left." << std::endl;
    } else {
        num_apart_on_sale --;
        player->add_apart(apartments[num_apart_on_sale]);
        apartments[num_apart_on_sale] = NULL;
    }
}
/*********************************************************************
** Function:buy_business
** Description:be able to buy property
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:buy property
*********************************************************************/

void Game::buy_business() {
    if (num_business_on_sale == 0) {
        std::cout << "No Business Complex left." << std::endl;
    } else {
        num_business_on_sale --;
        player->add_bussiness(businesses[num_business_on_sale]);
        businesses[num_business_on_sale] = NULL;
    }
}
/*********************************************************************
** Function:buy_property
** Description:be able to buy property
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:buy property
*********************************************************************/

void Game::handle_buy_property() {
    show_properties_on_sale();
    show_choices_to_buy();
    int type;
    std::cin >> type;
    if (type == 1) {
        buy_house();
    } else if (type == 2) {
        buy_apart();
    } else if (type == 3) {
        buy_business();
    } else {
        std::cout << "Invalid input." << std::endl;
    }
}
/*********************************************************************
** Function:handle_sell_property
** Description:be able to sell property
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:sell property
*********************************************************************/

void Game::handle_sell_property() {
    player->display_properties_list();
    if (player->get_total_number_of_properties() == 0) {
        std::cout << "You have no properties now. So you cannot sell a property." << std::endl;
    } else {
        std::cout << "Please Choose the type of property to sell:" << std::endl;
        std::cout << "1. House   2. Apartment Complex  3. Business Complex" << std::endl;
        int type;
        std::cin >> type;
        std::cout << "Please Choose the index of property to sell:";
        int index;
        std::cin >> index;
        if (type == 1) {
            player->sell_house(index);
        } else if (type == 2) {
            player->sell_apart(index);
        } else if (type == 3) {
            player->sell_bussiness(index);
        }
    }
}
/*********************************************************************
** Function: handle_adjust_rent
** Description:change the rent by user
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:change the rent value
*********************************************************************/

void Game::handle_adjust_rents() {
    player->display_properties_list();
    if (player->get_total_number_of_properties() == 0) {
        std::cout << "You have no properties now.";
    } else {
        std::cout << "Please Choose the type of property to adjust rent:" << std::endl;
        std::cout << "1. House   2. Apartment Complex  3. Business Complex" << std::endl;
        int type;
        std::cin >> type;
        std::cout << "Please Choose the index of property to adjust rent:";
        int index;
        std::cin >> index;
        if (type == 1 || type == 2) {
            player->adjust_rent(type ,index);
        } else if (type == 3) {
            player->adjust_rent(index);
        }
    }
}
/*********************************************************************
** Function:next_turn
** Description:go to next turn
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:switch turns
*********************************************************************/
void Game::next_turn() {
    curr_turn ++;
    std::cout << "==========Month " << curr_turn << "==========" << std::endl;
    update_BusinessComplex_value();
    update_bank();
    player->display_all_properties();
    if (is_end()) {
        return;
    }
    random_event();
    display_options();
    int choice = -1;
    std::cin >> choice;
    if (choice == 1) {
        handle_buy_property();
    } else if (choice == 2) {
        handle_sell_property();
    } else if (choice == 3) {
        handle_adjust_rents();
    }
}