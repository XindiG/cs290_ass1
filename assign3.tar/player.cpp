#include <iostream>
#include <cstdlib>
#include <ctime>
#include "player.h"
/*********************************************************************
** Program Filename:player.cpp
** Author:Xindi,Guo
** Date:2018/11/13
** Description:player.cpp
** Input:no
** Output:no
*********************************************************************/

/*********************************************************************
** Function:player_player
** Description:constructor
*********************************************************************/
Player::Player() {
    bank = 500000;
    num_apart = 0;
    num_business = 0;
    num_house = 0;
}

//destrcutor
Player::~Player(){

}
//mutator
double Player::get_bank() {
    return bank;
}
/*********************************************************************
** Function:add_house
** Description:add house space
** Parameters:house*h
** Pre-Conditions:no
** Post-Conditions:allocate one space
*********************************************************************/
 
void Player::add_house(House* h) {
    houses[num_house] = h;
    num_house ++;
}
/*********************************************************************
** Function:add_apartment
** Description:add space
** Parameters:apartmentcomplex*a
** Pre-Conditions:no
** Post-Conditions:allocate one space
*********************************************************************/

void Player::add_apart(ApartmentComplex* a) {
    aparts[num_apart] = a;
    num_apart ++;
}
/*********************************************************************
** Function:add_business
** Description:add space
** Parameters:businesscomplex*b
** Pre-Conditions:no
** Post-Conditions:allocate one space
*********************************************************************/

void Player::add_bussiness(BusinessComplex* b) {
    businesses[num_business] = b;
    num_business ++;
}
/*********************************************************************
** Function:sell_house
** Description:sell property
** Parameters:int index
** Pre-Conditions:no
** Post-Conditions:sell property
*********************************************************************/

House* Player::sell_house(int index) {
    if (index >= num_house || index < 0) {
        std::cout << "Invalid input." << std::endl;
        return NULL;
    }
    House* tmp = houses[index];
    if (tmp->get_number_tenants() > 0) {
        std::cout << "Fail to sell! there is a tenant in this House." << std::endl;
        return NULL;
    }
    for (int i = index; i < num_house - 2; i ++) {
        houses[i] = houses[i+1];
    }
    houses[num_house - 1] = NULL;
    num_house --;
    update_bank_after_sell(tmp);
    return tmp;
}
/*********************************************************************
** Function:sell_apart
** Description:sell property
** Parameters:int index
** Pre-Conditions:no
** Post-Conditions:sell property
*********************************************************************/

ApartmentComplex* Player::sell_apart(int index) {
    if (index >= num_apart || index < 0) {
        std::cout << "Invalid input." << std::endl;
        return NULL;
    }
    ApartmentComplex* tmp = aparts[index];
    if (tmp->get_number_tenants() > 0) {
        std::cout << "Fail to sell! there are tenants in this Apartment Complex." << std::endl;
        return NULL;
    }
    for (int i = index; i < num_apart - 2; i ++) {
        aparts[i] = aparts[i+1];
    }
    aparts[num_apart - 1] = NULL;
    num_apart --;
    update_bank_after_sell(tmp);
    return tmp;
}
/*********************************************************************
** Function:sell_bussiness
** Description:sell property
** Parameters:int index
** Pre-Conditions:no
** Post-Conditions:sell property
*********************************************************************/

BusinessComplex* Player::sell_bussiness(int index) {
    if (index >= num_business || index < 0) {
        std::cout << "Invalid input." << std::endl;
        return NULL;
    }
    BusinessComplex* tmp = businesses[index];
    if (tmp->get_number_tenants() > 0) {
        std::cout << "Fail to sell! there are tenants in this Business Complex." << std::endl;
        return NULL;
    }
    for (int i = index; i < num_business - 2; i ++) {
        businesses[i] = businesses[i+1];
    }
    businesses[num_business - 1] = NULL;
    num_business --;
    update_bank_after_sell(tmp);
    return tmp;
}

void Player::update_bank_after_sell(Property *p) {
    std::cout << "Please input your asking price:" << std::endl;
    double price;
    std::cin >> price;
    int random_number = rand()%3 + 1;
    if (random_number == 3) {
        bank = bank + price;
        std::cout << "You got your asking price." << std::endl;
    } else if (random_number == 2) {
        bank = bank + p->get_value();
        std::cout << "You got the property value." << std::endl;
    } else if (random_number == 1) {
        bank = bank + (1-0.1) * p->get_value();
        std::cout << "You got 10% less than the property value." << std::endl;
    }
}
/*********************************************************************
** Function:adjust_rent
** Description:change rent
** Parameters:int index int type
** Pre-Conditions:no
** Post-Conditions:change rent
*********************************************************************/ 

void Player::adjust_rent(int type, int index) {
    double rent;
    std::cout << "Please input new rent:" << std::endl;
    std::cin >> rent;
    if (type == 1) {
        if (index < 0 || index >= num_house) {
            std::cout << "Invalid inputs." << std::endl;
        } else {
            houses[index]->set_rent(rent);
        }
    } else if (type == 2) {
        if (index < 0 || index >= num_apart) {
            std::cout << "Invalid inputs." << std::endl;
        } else {
            aparts[index]->set_rent(rent);
        }
    }
}
/*********************************************************************
** Function:adjust_rent
** Description:change rent
** Parameters:int index
** Pre-Conditions:no
** Post-Conditions:change rent
*********************************************************************/ 

void Player::adjust_rent(int index) {
    if (index < 0 || index >= num_business) {
        std::cout << "Invalid inputs." << std::endl;
    } else {
        businesses[index]->display_room_info();
        std::cout << "Please input which room:" << std::endl;
        int room;
        std::cin >> room;
        if (room < 0 || room > businesses[index]->get_num_room()) {
            std::cout << "Invalid inputs." << std::endl;
            return;
        }
        double rent;
        std::cout << "Please input new rent:" << std::endl;
        std::cin >> rent;
        businesses[index]->set_rent(rent, room);
    }
}

void Player::update_business_value() {
    for (int i = 0; i < num_business; i++) {
        businesses[i]->update_value();
    }
}
/*********************************************************************
** Function:collect_rent
** Description:collect monthly rent
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:get rent value
*********************************************************************/

void Player::collect_rent() {
    for (int i = 0; i < num_house; i++) {
        bank += houses[i]->collect_rent();
    }
    for (int i = 0; i < num_apart; i++) {
        bank += aparts[i]->collect_rent();
    }
    for (int i = 0; i < num_business; i++) {
        bank += businesses[i]->collect_rent();
    }
}
/*********************************************************************
** Function:pay_mortgage
** Description:pay mortgage
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:mortgage paid and decrease bank value
*********************************************************************/ 

void Player::pay_mortgage() {
    for (int i = 0; i < num_house; i++) {
        bank -= houses[i]->mortgage_to_paid();
    }
    for (int i = 0; i < num_apart; i++) {
        bank -= aparts[i]->mortgage_to_paid();
    }
    for (int i = 0; i < num_business; i++) {
        bank -= businesses[i]->mortgage_to_paid();
    }
}
/*********************************************************************
** Function:pay_tax
** Description:pay tax
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:pay tax
*********************************************************************/


void Player::pay_tax() {
    double before = bank;
    for (int i = 0; i < num_house; i++) {
        bank -= houses[i]->tax_to_paid();
    }
    for (int i = 0; i < num_apart; i++) {
        bank -= aparts[i]->tax_to_paid();
    }
    for (int i = 0; i < num_business; i++) {
        bank -= businesses[i]->tax_to_paid();
    }
    std::cout << "Pay tax:" << (before - bank) << std::endl;
}
/*********************************************************************
** Function:decrease_value_by_event
** Description:no
** Parameters:int location double decrease_rate
** Pre-Conditions:no
** Post-Conditions:decrease the property value by event happend
*********************************************************************/ 

void Player::decrease_value_by_event(int location, double decrease_rate) {
    for (int i = 0; i < num_house; i ++) {
        if (houses[i] != NULL && houses[i]->get_location() == location) {
            houses[i]->decrease_value(decrease_rate);
        }
    }
    for (int i = 0; i < num_apart; i ++) {
        if (aparts[i] != NULL && aparts[i]->get_location() == location) {
            aparts[i]->decrease_value(decrease_rate);
        }
    }
    for (int i = 0; i < num_business; i ++) {
        if (businesses[i] != NULL && businesses[i]->get_location() == location) {
            businesses[i]->decrease_value(decrease_rate);
        }
    }
}
/*********************************************************************
** Function:display_all_properties
** Description:no
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:show properies informations
*********************************************************************/ 

void Player::display_all_properties() {
    std::cout << "Your bank now:" << get_bank() << std::endl << "Your properties:" << std::endl;
    for (int i = 0; i < num_house; i ++) {
        std::cout << "House " << i << ":" << std::endl;
        houses[i]->display();
        houses[i]->display_room_info();
    }
    for (int i = 0; i < num_apart; i ++) {
        std::cout << "Apartment Complex " << i << ":" << std::endl;
        aparts[i]->display();
        aparts[i]->display_room_info();
    }
    for (int i = 0; i < num_business; i ++) {
        std::cout << "Business Complex " << i << ":" << std::endl;
        businesses[i]->display();
        businesses[i]->display_room_info();
    }
    if (num_house == 0 && num_apart == 0 && num_business == 0) {
        std::cout << "You have no properties now." << std::endl;
    }
}
 /*********************************************************************
** Function:display_properties_list
** Description:no
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:show properies informations that you want sell
*********************************************************************/ 

void Player::display_properties_list() {
    std::cout << "Your properties list:(You need to choose one from this list) "<< std::endl;
    std::cout << "Type               index"<< std::endl;
    for (int i = 0; i < num_house; i ++) {
        std::cout << "House              " << i << std::endl;
    }
    for (int i = 0; i < num_apart; i ++) {
        std::cout << "Apartment Complex  " << i << std::endl;
    }
    for (int i = 0; i < num_business; i ++) {
        std::cout << "Business Complex   " << i << std::endl;
    }
    if (num_house == 0 && num_apart == 0 && num_business == 0) {
        std::cout << "You have no properties now." << std::endl;
    }
}
/*********************************************************************
** Function:Player::get_total_number_of_properties
** Description:get number of total property
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:return number
*********************************************************************/

int Player::get_total_number_of_properties() {
    return num_house + num_apart + num_business;
}

