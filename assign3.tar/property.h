#ifndef INC_11_13_PROPERTY_H
#define INC_11_13_PROPERTY_H

#include "tenant.h"
#include <string>
/*********************************************************************
** Program Filename:property.h
** Author:Xindi,Guo
** Date:2018/11/13
** Description:propertys'header
** Input:no
** Output:no
*********************************************************************/
class Property {
public:
    Property();
    double get_tax();
    double get_mortgage();
    int get_location();
    std::string location_to_string();
    double get_value();
    void set_tax();
    void set_value(int low, int up); // low and up 's unit: thousand
    void set_value(double v);  // only be used to update value for Business Complex
    void set_location();
    void set_mortgage();

    void decrease_value(double decrease_rate); // after event occur
    bool is_paid_off(); // if mortgage was paid off. if not ,player should continue pay
    double mortgage_to_paid(); //if mortgage was paid off, return 0; else return monthly mortgage
    double tax_to_paid(); // return tax
    void display(); // display property information

    // virtual functions. (Polymorphism)
    // since three child class will have different ways.

    // collect monthly rent.
    // For House, just one tenant;
    // For Apartment Complex, many tenants and same rent;
    // For Business Complex, many tenants and different rent.
    virtual double collect_rent() = 0;

    // display rooms information
    virtual void display_room_info() = 0;

    // count the number of tenants.
    // For House, just one or zero tenant;
    // For Apartment Complex and Business Complex, might have more than one tenants;
    virtual int get_number_tenants() = 0;

private:
    double value;
    double mortgage;
    double duration_mortgage;
    int location; //0 means SE, 1 means NE, 2 means Midwest, 3 means SW, 4 means NW
    double tax;
};


class House: public Property {
public:
    House();
    void set_rent(double r);

    //override!
    double collect_rent();
    void display_room_info();
    int get_number_tenants();

private:
    Tenant* tenant;
    double rent;
};

class RoomInfo {
public:
    bool has_tenant;
    Tenant* tenant;
    double rent; // only used in BusinessComplex
    int size; // only used in BusinessComplex and 0 means small, 1 means medium, 2 means large
};

class ApartmentComplex: public Property {
public:
    ApartmentComplex();
    void set_tenants();
    void set_num_room();
    void set_rent(double r);

    //override!
    double collect_rent();
    void display_room_info();
    int get_number_tenants();

private:
    int num_rooms;
    RoomInfo rooms[10];
    double rent;
};

class BusinessComplex: public Property {
public:
    BusinessComplex();
    void set_tenants();
    void set_num_room();
    void set_rent(double r, int index);

    int get_num_room();
    void update_value();

    //override!
    double collect_rent();
    void display_room_info();
    int get_number_tenants();

private:
    int num_rooms;
    RoomInfo rooms[5];
};

#endif
