#ifndef INC_11_13_PLAYER_H
#define INC_11_13_PLAYER_H

#include "property.h"
/*********************************************************************
** Program Filename:player.h
** Author:Xindi,Guo
** Date:2018/11/13
** Description:player'header
** Input:no
** Output:no
*********************************************************************/
class Player {
public:
    Player();
    ~Player();
    double get_bank();
    void add_house(House* h); // buy a House
    void add_apart(ApartmentComplex* a); // buy a ApartmentComplex
    void add_bussiness(BusinessComplex* b); // buy a BusinessComplex
    House* sell_house(int index); // sell a House
    ApartmentComplex* sell_apart(int index); // sell a ApartmentComplex
    BusinessComplex* sell_bussiness(int index); // sell a BusinessComplex
    void update_bank_after_sell(Property *p);
    void adjust_rent(int type, int index); //except for Business Complex
    void adjust_rent(int index); //for Business Complex

    // Each business that pays rent in a complex
    // increases the property value by 1% each turn.
    void update_business_value();

    void collect_rent();
    void pay_mortgage();
    void pay_tax();
    void decrease_value_by_event(int location, double decrease_rate);
    void display_all_properties();
    void display_properties_list();
    int get_total_number_of_properties();

private:
    double bank;
    int num_house;
    int num_apart;
    int num_business;
    House* houses[100];
    ApartmentComplex* aparts[100];
    BusinessComplex* businesses[100];
};

#endif
