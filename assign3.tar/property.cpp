#include "property.h"
#include <cstdlib>
#include<string>
#include <iostream>
/*********************************************************************
** Program Filename:property.cpp
** Author:Xindi,Guo
** Date:2018/11/13
** Description:property's header
** Input:no
** Output:no
*********************************************************************/


/*********************************************************************
** Function:tnenat_tenant
** Description:constructor
*********************************************************************/

Property::Property() {
    set_tax();
    set_location();
    set_mortgage();
    duration_mortgage = 0;
}
/*********************************************************************
** Function:get_tax
** Description:get the value
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:no
*********************************************************************/

double Property::get_tax() {
    return tax;
}
/*********************************************************************
** Function:get_mortgage
** Description:get the value
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:no
*********************************************************************/

double Property::get_mortgage() {
    return mortgage;
}

/*********************************************************************
** Function:get_location
** Description:get the value
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:no
*********************************************************************/
int Property::get_location() {
    return location;
}
/*********************************************************************
** Function:location_to_string
** Description:random set the location
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:set locations to property
*********************************************************************/
std::string Property::location_to_string() {
    //0 means SE, 1 means NE, 2 means Midwest, 3 means SW, 4 means NW
    std::string tmp;
    if (location == 0) {
        tmp = "SE";
    } else if (location == 1) {
        tmp = "NE";
    } else if (location == 2) {
        tmp = "Midwest";
    } else if (location == 3) {
        tmp = "SW";
    } else if (location == 4) {
        tmp = "NW";
    }
    return tmp;
}
/*********************************************************************
** Function:get_value
** Description:get the value
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:no
*********************************************************************/
double Property::get_value() {
    return value;
}

/*********************************************************************
** Function:set_tax
** Description:set the value
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:no
*********************************************************************/
void Property::set_tax() {
    tax = 0.015;
}
/*********************************************************************
** Function:set_value
** Description:set the value
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:no
*********************************************************************/

void Property::set_value(int low, int up) {
    value = ((rand()%(up-low+1)) + low) * 1000;
}
/*********************************************************************
** Function:get_value
** Description:set the value
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:no
*********************************************************************/

void Property::set_value(double v) {
    value = v;
}
/*********************************************************************
** Function:set_location
** Description:set the value
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:no
*********************************************************************/
void Property::set_location() {
    location = rand()%5;
}
/*********************************************************************
** Function:set_mortgage
** Description:set the value
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:no
*********************************************************************/
void Property::set_mortgage() {
    mortgage = rand()%5001;
}
/*********************************************************************
** Function:mortgage_to_paid
** Description:pay mortgage
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:pay mortgage
*********************************************************************/

double Property::mortgage_to_paid() {
    if (is_paid_off()) {
        return 0;
    }
    return mortgage;
}
/*********************************************************************
** Function:tax_to_paid
** Description:pay tax
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:pay tax
*********************************************************************/

double Property::tax_to_paid() {
    return tax*value;
}
/*********************************************************************
** Function:decrease_value
** Description:decrease the value
** Parameters:double decrease_rate
** Pre-Conditions:no
** Post-Conditions:change value
*********************************************************************/

void Property::decrease_value(double decrease_rate) {
    value = value * (1 - decrease_rate);
}
/*********************************************************************
** Function:is_paid_off
** Description:check duration is bigger than vaule
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:check
*********************************************************************/
bool Property::is_paid_off(){
    if (duration_mortgage >= value) {
        return true;
    }
    return false;
}
/*********************************************************************
** Function:display
** Description:print the property info
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:display infomations
*********************************************************************/

void Property::display() {
    std::cout << "value: " << value << std::endl;
    std::cout << "location: " << location_to_string() << std::endl;
    std::cout << "mortgage: " << mortgage << std::endl;
}
/*********************************************************************
** Function:house_house
** Description:constructor
*********************************************************************/

House::House() {
    set_value(100, 600);
    tenant = new Citizen();
    rent = 500.0;
}
//mutator

void House::set_rent(double r) {
    rent = r;
    if (rent > tenant->get_monthly_budget() && tenant->get_agree_score() >= 2) {
        delete tenant;
    }
}
/*********************************************************************
** Function:collect_rent
** Description:collect monthly rent
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:get rent value
*********************************************************************/

double House::collect_rent() {
    if (tenant != NULL && rent <= tenant->get_monthly_budget()) {
        return rent;
    }
    return 0;
}
/*********************************************************************
** Function:display_room_info
** Description:print the room info
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:display infomations
*********************************************************************/

void House::display_room_info() {
    std::cout << "Has tenant: ";
    if (tenant != NULL) {
        std::cout << "Yes." << std::endl;
    } else {
        std::cout << "No." << std::endl;
    }
    std::cout << "rent: " << rent << std::endl;
}
/*********************************************************************
** Function:get_number_tenant
** Description:check is there is tenant
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:check result
*********************************************************************/

int House::get_number_tenants() {
    if (tenant == NULL) {
        return 0;
    }
    return 1;
}
/*********************************************************************
** Function:tnenat_tenant
** Description:constructor
*********************************************************************/

ApartmentComplex::ApartmentComplex() {
    set_value(300, 600);
    set_num_room();
    set_tenants();
    rent = 500.0;
}
//mutator set random room

void ApartmentComplex::set_num_room() {
    num_rooms = rand()%10 + 1;
}
/*********************************************************************
** Function:set_tenant
** Description:set tenants
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:set tenant for property
*********************************************************************/

void ApartmentComplex::set_tenants() {
    for (int i = 0; i < 10; i++) {
        rooms[i].tenant = NULL;
        rooms[i].has_tenant = false;
    }

    for (int i = 0; i < num_rooms; i++) {
        rooms[i].tenant = new Citizen();
        rooms[i].has_tenant = true;
    }
}
/*********************************************************************
** Function:set_rent
** Description:set monthly rent
** Parameters:double r
** Pre-Conditions:no
** Post-Conditions:adjust rent
*********************************************************************/
void ApartmentComplex::set_rent(double r) {
    rent = r;
    for (int i = 0; i < num_rooms; i++) {
        if (rooms[i].has_tenant) {
            if (rooms[i].tenant->get_agree_score() >= 2
                && rooms[i].tenant->get_monthly_budget() < rent) {
                rooms[i].has_tenant = false;
                delete rooms[i].tenant;
            }
        }
    }
}
/*********************************************************************
** Function:collect_rent
** Description:collect monthly rent
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:get rent value
*********************************************************************/

double ApartmentComplex::collect_rent() {
    double total = 0.0;
    for (int i = 0; i < num_rooms; i++) {
        if (rooms[i].has_tenant && rent <= rooms[i].tenant->get_monthly_budget()) {
            total = total + rent;
        }
    }
    return total;
}
/*********************************************************************
** Function:display_room_info
** Description:print the room info
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:display infomations
*********************************************************************/

void ApartmentComplex::display_room_info() {
    int num = 0;
    for (int i = 0; i < num_rooms; i++) {
        if (rooms[i].has_tenant) {
            num ++;
        }
    }
    std::cout << "Has tenants: ";
    if (num == 0) {
        std::cout << "No" << std::endl;
    } else {
        std::cout << "Yes" << std::endl;
    }
    std::cout << "rent: " << rent << std::endl;
}
/*********************************************************************
** Function:get_number_tenants
** Description:get the number of tenants
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:get the number of tenants
*********************************************************************/
int ApartmentComplex::get_number_tenants() {
    int num = 0;
    for (int i = 0; i < num_rooms; i++) {
        if (rooms[i].has_tenant) {
            num ++;
        }
    }
    return num;
}
/*********************************************************************
** Function:tnenat_tenant
** Description:constructor
*********************************************************************/

BusinessComplex::BusinessComplex() {
    set_value(400, 600);
    set_num_room();
    set_tenants();
}
//mutator set random rooms
 
void BusinessComplex::set_num_room() {
    num_rooms = rand()%5 + 1;
}
/*********************************************************************
** Function:set_tenant
** Description:set tenants
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:set tenant for property
*********************************************************************/

void BusinessComplex::set_tenants() {
    for (int i = 0; i < 5; i++) {
        rooms[i].tenant = NULL;
        rooms[i].has_tenant = false;
    }

    for (int i = 0; i < num_rooms; i++) {
        rooms[i].tenant = new Business();
        rooms[i].has_tenant = true;
        rooms[i].size = rand()%3;
        rooms[i].rent = 500.0;
    }
}
/*********************************************************************
** Function:set_rent
** Description:set monthly rent
** Parameters:double r, int index
** Pre-Conditions:no
** Post-Conditions:adjust rent
*********************************************************************/
void BusinessComplex::set_rent(double r, int index) {
    rooms[index].rent = r;
    if (rooms[index].rent > rooms[index].tenant->get_monthly_budget()
                             && rooms[index].tenant->get_agree_score() >= 2) {
        rooms[index].has_tenant = false;
        delete rooms[index].tenant;
    }
}
/*********************************************************************
** Function:get_number_room
** Description:get the number of room
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:get the number of room
*********************************************************************/
int BusinessComplex::get_num_room() {
    return num_rooms;
}
/*********************************************************************
** Function:update_value
** Description:change value when event happends or something could change the value
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:set up the change
*********************************************************************/

void BusinessComplex::update_value() {
    int num = 0;
    for (int i = 0; i < num_rooms; i++) {
        if (rooms[i].has_tenant && rooms[i].rent <= rooms[i].tenant->get_monthly_budget()) {
            num ++;
        }
    }
    set_value(get_value()*(1.0+(double)num*0.01));
}
/*********************************************************************
** Function:collect_rent
** Description:collect monthly rent
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:get rent value
*********************************************************************/

double BusinessComplex::collect_rent() {
    double total = 0.0;
    for (int i = 0; i < num_rooms; i++) {
        if (rooms[i].has_tenant && rooms[i].rent <= rooms[i].tenant->get_monthly_budget()) {
            total = total + rooms[i].rent;
        }
    }
    return total;
}
/*********************************************************************
** Function:display_room_info
** Description:print the room info
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:display infomations
*********************************************************************/

void BusinessComplex::display_room_info() {
    std::cout << "Has tenants: ";
    if (get_number_tenants() == 0) {
        std::cout << "No" << std::endl;
    } else {
        std::cout << "Yes" << std::endl;
    }
    for (int i = 0; i < num_rooms; i++) {
        std::cout << "room " << i << " rent: " << rooms[i].rent << std::endl;
    }
}
/*********************************************************************
** Function:get_number_tenants
** Description:get the number of tenants
** Parameters:no
** Pre-Conditions:no
** Post-Conditions:get the number of tenants
*********************************************************************/

int BusinessComplex::get_number_tenants() {
    int num = 0;
    for (int i = 0; i < num_rooms; i++) {
        if (rooms[i].has_tenant) {
            num ++;
        }
    }
    return num;
}
